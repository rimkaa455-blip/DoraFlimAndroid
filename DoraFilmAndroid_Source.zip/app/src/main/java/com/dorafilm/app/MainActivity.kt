package com.dorafilm.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1C1C1C)
private val Gold = Color(0xFFD4AF37)
private val Cream = Color(0xFFF5EAC8)

data class Film(val title: String, val category: String, val description: String, val videoUrl: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DoraFilmApp() }
    }
}

@Composable
fun DoraFilmApp() {
    val context = LocalContext.current
    val films = remember {
        mutableStateListOf(
            Film("Fim na 1", "Sabon", "Wannan wuri ne na misalin fim. Admin zai iya maye gurbinsa da bayanan fim na gaske.", ""),
            Film("Fim na 2", "Drama", "Saka taƙaitaccen bayanin fim a nan.", "")
        )
    }
    val favorites = remember { mutableStateListOf<String>() }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Gida") }
    var showAdmin by remember { mutableStateOf(false) }
    var adminPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Drama") }
    var newDescription by remember { mutableStateOf("") }
    var newUrl by remember { mutableStateOf("") }
    var selectedFilm by remember { mutableStateOf<Film?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Black, background = Black, surface = Panel,
        onBackground = Cream, onSurface = Cream
    )) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("DORA FILM", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("Kalli fina-finai kyauta", color = Cream.copy(alpha = .7f), fontSize = 12.sp)
                    }
                    TextButton(onClick = { showAdmin = true }) { Text("ADMIN", color = Gold) }
                }
                if (selectedFilm != null) {
                    FilmDetails(selectedFilm!!, favorites.contains(selectedFilm!!.title),
                        onFavorite = {
                            val name = selectedFilm!!.title
                            if (favorites.contains(name)) favorites.remove(name) else favorites.add(name)
                        },
                        onPlay = {
                            val url = selectedFilm!!.videoUrl
                            if (url.isNotBlank()) context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        },
                        onBack = { selectedFilm = null })
                } else if (showAdmin) {
                    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ADMIN DASHBOARD", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Wannan sigar gwaji ce. Canza PIN kafin amfani na gaske.", color = Cream.copy(alpha=.7f))
                        OutlinedTextField(adminPin, { adminPin = it; pinError = false }, label = { Text("PIN na Admin") })
                        Button(onClick = { if (adminPin == "2468") pinError = false else pinError = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Shiga", color = Black) }
                        if (pinError) Text("PIN bai yi daidai ba. PIN na gwaji: 2468", color = Color.Red)
                        if (adminPin == "2468") {
                            Divider(color = Gold)
                            OutlinedTextField(newTitle, { newTitle = it }, label = { Text("Sunan fim") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(newCategory, { newCategory = it }, label = { Text("Nau'in fim") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(newDescription, { newDescription = it }, label = { Text("Bayanin fim") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(newUrl, { newUrl = it }, label = { Text("Video URL (https)") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                if (newTitle.isNotBlank()) {
                                    films.add(Film(newTitle.trim(), newCategory.trim(), newDescription.trim(), newUrl.trim()))
                                    newTitle = ""; newDescription = ""; newUrl = ""
                                }
                            }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                Text("Saka fim", color = Black)
                            }
                            Text("Fina-finai: ${films.size}", color = Cream)
                            films.forEach { film ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(film.title, Modifier.weight(1f), color = Cream)
                                    TextButton(onClick = { films.remove(film) }) { Text("Goge", color = Color.Red) }
                                }
                            }
                        }
                        TextButton(onClick = { showAdmin = false; adminPin = "" }) { Text("Komawa gida", color = Gold) }
                    }
                } else {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        placeholder = { Text("Nemo fim...") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true, shape = RoundedCornerShape(14.dp)
                    )
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Gida", "Duk fina-finai", "Abubuwan so").forEach { label ->
                            FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
                        }
                    }
                    LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                        item {
                            Text("Fina-finai", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 12.dp))
                        }
                        val visible = films.filter {
                            it.title.contains(query, true) || it.category.contains(query, true)
                        }.filter { tab != "Abubuwan so" || favorites.contains(it.title) }
                        items(visible) { film ->
                            Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { selectedFilm = film },
                                colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(64.dp, 82.dp).background(Color(0xFF332A12), RoundedCornerShape(10.dp)),
                                        contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Movie, null, tint = Gold, modifier = Modifier.size(34.dp))
                                    }
                                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                        Text(film.title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                        Text(film.category, color = Gold, fontSize = 12.sp)
                                        Text(film.description, color = Cream.copy(alpha=.65f), maxLines = 2, fontSize = 12.sp)
                                    }
                                    Icon(Icons.Default.PlayCircle, null, tint = Gold, modifier = Modifier.size(30.dp))
                                }
                            }
                        }
                        if (visible.isEmpty()) item { Text("Ba a sami fim ba.", color = Cream.copy(alpha=.7f)) }
                    }
                    Text("Tallace-tallace za su bayyana a nan bayan haɗa AdMob.",
                        color = Cream.copy(alpha=.45f), fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().background(Panel).padding(12.dp))
                }
            }
        }
    }
}

@Composable
fun FilmDetails(film: Film, isFavorite: Boolean, onFavorite: () -> Unit, onPlay: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onBack) { Text("← Komawa", color = Gold) }
        Box(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF332A12), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Movie, null, tint = Gold, modifier = Modifier.size(90.dp))
        }
        Text(film.title, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(film.category, color = Cream.copy(alpha=.7f))
        Text(film.description, color = Cream)
        Button(onClick = onPlay, enabled = film.videoUrl.startsWith("https://"),
            colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
            Icon(Icons.Default.PlayArrow, null, tint = Black)
            Text(" Kalli yanzu", color = Black)
        }
        OutlinedButton(onClick = onFavorite) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Gold)
            Text(if (isFavorite) " An ajiye" else " Ajiye a abubuwan so", color = Gold)
        }
        if (film.videoUrl.isBlank()) Text("Admin bai saka hanyar kallon fim ba tukuna.", color = Cream.copy(alpha=.6f))
    }
}
