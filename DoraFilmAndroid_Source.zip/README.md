# DORA FILM — Android starter

Wannan shi ne farkon aikin Android na DORA FILM, cikin Hausa da launukan Black & Gold.

## Abubuwan da ke ciki
- Shafin gida da jerin fina-finai
- Bincike
- Bayanin fim da maɓallin kunna bidiyo (yana buɗe HTTPS video link)
- Abubuwan da aka fi so (a lokacin amfani)
- Shafin Admin na gwaji don ƙara/goge fina-finai
- Wurin talla a matsayin placeholder

## Buɗewa da gina APK
1. Sanya Android Studio a kwamfuta.
2. Buɗe wannan folder a Android Studio.
3. Jira Gradle Sync ya gama.
4. Zaɓi **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK zai bayyana a `app/build/outputs/apk/debug/app-debug.apk`.

## Muhimman abubuwan da ba a gama ba
- Admin PIN `2468` PIN ne na gwaji kawai. Ba tsaro ba ne; a maye gurbinsa da ingantaccen shiga kafin fitarwa.
- Fina-finai da aka ƙara suna cikin memory ne kawai; ba sa dawwama bayan an rufe app.
- Ba a haɗa Firebase/backend, cloud storage, AdMob, ko ingantaccen tsarin admin ba tukuna.
- Ana buƙatar izinin mallaka ko lasisin watsawa ga duk fim da za a saka.
- Video URL dole ne ya zama HTTPS kuma ya dace da Android player/mai buɗe bidiyo.

Wannan aikin tushen farawa ne, ba APK da aka riga aka gina ba.
